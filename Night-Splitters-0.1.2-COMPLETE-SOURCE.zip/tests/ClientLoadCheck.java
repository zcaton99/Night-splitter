import net.fabricmc.api.EnvType;
import net.fabricmc.loader.impl.launch.knot.Knot;
import net.fabricmc.loader.impl.FabricLoaderImpl;
public class ClientLoadCheck {
 public static void main(String[] args) throws Exception {
   Knot knot = new Knot(EnvType.CLIENT);
   ClassLoader cl = knot.init(new String[]{"--gameDir",System.getProperty("user.dir"),"--version","26.3"});
   boolean present = FabricLoaderImpl.INSTANCE.isModLoaded("night_splitters");
   System.out.println("CLIENT_ENV_MOD_PRESENT="+present);
   if (!present) throw new AssertionError("Night Splitters was skipped in the client environment");
   Class<?> type=cl.loadClass("com.rdt.nightsplitters.NightSplitters");
   Object mod=type.getConstructor().newInstance();
   type.getMethod("onInitialize").invoke(mod);
   System.out.println("CLIENT_ENV_INITIALIZER_PASS");
 }
}
