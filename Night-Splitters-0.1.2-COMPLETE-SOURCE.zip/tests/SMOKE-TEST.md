# In-game acceptance checks (on a new single-player test world or backed-up server copy)

1. Start 26.3 + Fabric Loader 0.20.1 + Fabric API 0.165.0+26.3 + this jar. Confirm its initialization log and `/nightsplitters status`.
2. As a Survival player, stand outdoors on open ground, away from torchlight. Set night and wait 20–40 seconds. Expect fast cave spiders to approach from 24–40 blocks away. Failed location searches can yield fewer than six.
3. Kill a parent. Expect exactly two visibly half-sized offspring. Kill each child and confirm neither splits.
4. Kill a normal cave spider not spawned by the mod. It must not split.
5. Set day. Tracked living swarm spiders should disappear within a second; normal spiders remain.
6. Set night, wait for another wave, then `/nightsplitters disable`. Expect zero tracked living swarm spiders and no further waves. Restart: it must remain disabled. `/nightsplitters enable` resumes it.
7. With two nearby players, check that local reservations prevent runaway waves. A parent costs 2 slots; a child costs 1. Check status as parents split: reservation totals must not increase.
8. Repeat with your existing horror mods and watch server MSPT/TPS. This combination has not been tested here. Mods that cancel deaths, transform spiders, change time, or override targeting may change the behavior.
