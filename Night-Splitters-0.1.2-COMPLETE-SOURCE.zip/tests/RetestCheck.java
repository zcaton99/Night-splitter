import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.fabric.api.event.lifecycle.v1.*;
import net.minecraft.server.level.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.monster.spider.CaveSpider;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.gamerules.GameRules;
import com.mojang.authlib.GameProfile;
import com.rdt.nightsplitters.*;
import java.util.*;
import java.lang.reflect.*;
public class RetestCheck implements ModInitializer {
 int ticks; NightSplitters mod; Field next; Method tick,slots,clear; SwarmConfig cfg;
 static void check(boolean pass,String message){if(!pass)throw new AssertionError(message);System.out.println("RETEST PASS: "+message);}
 static List<CaveSpider> alive(ServerLevel l){var out=new ArrayList<CaveSpider>();for(var e:l.getAllEntities())if(e instanceof CaveSpider sp && sp.isAlive() && sp.entityTags().contains("ns_swarm"))out.add(sp);return out;}
 public void onInitialize(){
  ServerLifecycleEvents.SERVER_STARTED.register(s->{for(int x=-3;x<=3;x++)for(int z=-3;z<=3;z++)s.getLevel(Level.OVERWORLD).setChunkForced(x,z,true);});
  ServerLifecycleEvents.SERVER_STOPPED.register(s->{try{
   if(mod!=null){Field loaded=NightSplitters.class.getDeclaredField("loaded");loaded.setAccessible(true);check(((Map<?,?>)loaded.get(mod)).isEmpty() && next.getLong(mod)==0,"server-stop state reset");}
  }catch(Exception e){throw new RuntimeException(e);}});
  ServerTickEvents.END_SERVER_TICK.register(s->{
   if(++ticks!=200)return;
   ServerLevel l=s.getLevel(Level.OVERWORLD);ServerPlayer p=null;
   try{
    mod=(NightSplitters)FabricLoader.getInstance().getEntrypoints("main",ModInitializer.class).stream().filter(m->m instanceof NightSplitters).findFirst().orElseThrow();
    next=NightSplitters.class.getDeclaredField("nextWave");next.setAccessible(true);
    Field cf=NightSplitters.class.getDeclaredField("config");cf.setAccessible(true);cfg=(SwarmConfig)cf.get(mod);
    tick=NightSplitters.class.getDeclaredMethod("tick",net.minecraft.server.MinecraftServer.class);tick.setAccessible(true);
    slots=NightSplitters.class.getDeclaredMethod("slots",ServerPlayer.class);slots.setAccessible(true);
    clear=NightSplitters.class.getDeclaredMethod("clear");clear.setAccessible(true);clear.invoke(mod);
    cfg.enabled=true;cfg.cleanupAtDawn=true;cfg.globalSlotCap=12;cfg.localSlotCap=12;cfg.parentsPerWave=6;
    p=new ServerPlayer(s,l,new GameProfile(UUID.randomUUID(),"WaveProbe"),ClientInformation.createDefault());p.setPos(0,-60,0);
    check(!p.isCreative()&&!p.isSpectator()&&p.isAlive(),"simulated Survival player eligible");
    // Temporarily expose the player only while invoking the production wave logic.
    // Remove before any ordinary world/network tick, so no fake network handler is needed.
    l.players().add(p);
    s.getCommands().performPrefixedCommand(s.createCommandSourceStack(),"time set night");
    next.setLong(mod,0);tick.invoke(mod,s);
    int parents=alive(l).size();check(parents==6,"automatic wave spawned six parents");
    check((int)slots.invoke(mod,(Object)null)==12,"parent offspring reservations at cap");
    long scheduled=next.getLong(mod);tick.invoke(mod,s);check(alive(l).size()==parents&&next.getLong(mod)==scheduled,"wave interval blocks immediate repeat");
    next.setLong(mod,0);tick.invoke(mod,s);check(alive(l).size()==parents,"global/local cap blocks extra parents");
    CaveSpider first=alive(l).getFirst();check(Math.abs(first.getAttributeValue(Attributes.MOVEMENT_SPEED)-.6)<.00001,"parent speed is 2x");
    first.kill(l);check(alive(l).size()==7,"one parent becomes exactly two offspring");
    check((int)slots.invoke(mod,(Object)null)==12,"split keeps reservation budget unchanged");
    var children=alive(l).stream().filter(sp->sp.entityTags().contains("ns_child")).toList();
    for(var child:children){check(Math.abs(child.getAttributeValue(Attributes.SCALE)-.5)<.00001,"child scale 0.5");check(Math.abs(child.getAttributeValue(Attributes.MOVEMENT_SPEED)-.66)<.00001,"child speed 2.2x");child.kill(l);}
    check(alive(l).size()==5,"offspring deaths do not split");
    next.setLong(mod,0);tick.invoke(mod,s);check(alive(l).size()==6,"freed slots refill without exceeding cap");
    s.getCommands().performPrefixedCommand(s.createCommandSourceStack(),"time set day");next.setLong(mod,0);tick.invoke(mod,s);check(alive(l).isEmpty(),"daytime cleanup and no daytime wave");
    s.getCommands().performPrefixedCommand(s.createCommandSourceStack(),"time set night");
    l.getGameRules().set(GameRules.SPAWN_MOBS,false,s);next.setLong(mod,0);tick.invoke(mod,s);check(alive(l).isEmpty(),"mob spawning gamerule respected");l.getGameRules().set(GameRules.SPAWN_MOBS,true,s);
    l.getGameRules().set(GameRules.SPAWN_MONSTERS,false,s);next.setLong(mod,0);tick.invoke(mod,s);check(alive(l).isEmpty(),"monster spawning gamerule respected");l.getGameRules().set(GameRules.SPAWN_MONSTERS,true,s);
    next.setLong(mod,0);tick.invoke(mod,s);check(alive(l).size()==6,"waves resume after gamerules restored");
    s.getCommands().performPrefixedCommand(s.createCommandSourceStack(),"nightsplitters disable");check(alive(l).isEmpty()&&!cfg.enabled,"disable clears without offspring");next.setLong(mod,0);tick.invoke(mod,s);check(alive(l).isEmpty(),"disabled mod does not spawn");
    s.getCommands().performPrefixedCommand(s.createCommandSourceStack(),"nightsplitters enable");next.setLong(mod,0);tick.invoke(mod,s);check(alive(l).size()==6,"enable restores waves");
    for(var spider:alive(l)){for(String tag:List.copyOf(spider.entityTags()))if(tag.startsWith("ns_exp_"))spider.removeTag(tag);spider.addTag("ns_exp_0");}
    next.setLong(mod,Long.MAX_VALUE);tick.invoke(mod,s);check(alive(l).isEmpty(),"expired swarm removed without splitting");
    var ordinary=EntityTypes.CAVE_SPIDER.create(l,EntitySpawnReason.EVENT);ordinary.setPos(0,-60,0);l.addFreshEntity(ordinary);ordinary.kill(l);check(alive(l).isEmpty(),"ordinary cave spiders unaffected");
    System.out.println("RETEST ALL CHECKS PASSED");
   }catch(Throwable error){System.out.println("RETEST FAILED");error.printStackTrace();}
   finally{if(p!=null)l.players().remove(p);}
  });
 }
}
