import com.rdt.nightsplitters.SwarmBudget;
import com.rdt.nightsplitters.SwarmConfig;
public class CoreChecks {
    public static void main(String[] args) {
        for (int cap=2;cap<=256;cap++) for(int occupied=0;occupied<=cap+2;occupied++) {
            if (SwarmBudget.canAddParent(occupied,cap) && occupied+2>cap) throw new AssertionError("cap");
        }
        if (SwarmBudget.cost(true) != 2*SwarmBudget.cost(false)) throw new AssertionError("split reservation");
        new SwarmConfig().validate();
        SwarmConfig invalid=new SwarmConfig();invalid.parentSpeedMultiplier=Double.NaN;
        try {invalid.validate();throw new AssertionError("NaN accepted");}catch(IllegalArgumentException expected){}
        invalid=new SwarmConfig();invalid.globalSlotCap=257;
        try {invalid.validate();throw new AssertionError("unbounded cap accepted");}catch(IllegalArgumentException expected){}
        System.out.println("PASS: population reservation boundaries and unsafe configuration rejection");
    }
}
