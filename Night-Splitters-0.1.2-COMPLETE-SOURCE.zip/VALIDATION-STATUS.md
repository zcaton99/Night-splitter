# Night Splitters 0.1.2 source status

Source includes 2–3 spider waves, 5–30 second randomized cooldown after tracked spiders clear, 25% slower defaults, Creative pursuit, and a Creative-only half-damage Mixin attempt.

**NOT COMPILED OR GAMEPLAY TESTED.** The `hurtServer` variable modifier and `isInvulnerableTo` injection require verification against Minecraft 26.3 mappings. GitHub Actions will attempt compilation but may report errors. The original TEST.jar remains the fallback.

**Known caveats:** the wave system tracks loaded spiders, so unloading chunks can affect wave completion; Creative half damage depends on actual game damage flow and needs in-game verification; existing config files preserve old speed values unless updated.
