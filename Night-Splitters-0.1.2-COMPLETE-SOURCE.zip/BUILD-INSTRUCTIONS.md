# Night Splitters 0.1.2 — GitHub build

This is **source code**, not a compiled JAR. The GitHub Actions workflow attempts a Java 25 build. Compilation and gameplay are **not yet verified**.

1. Create a new GitHub repository (public or private).
2. Upload **the contents of this ZIP**, including the hidden `.github/workflows/build.yml` file, to the repository root. GitHub may require uploading the workflow through its web editor if workflow upload is restricted.
3. Open **Actions → Build Night Splitters Java 25 → Run workflow**.
4. Open the run, read any errors, and if green download the `night-splitters-0.1.2-test` artifact.
5. Extract the artifact and use the remapped mod JAR, **not** the `-sources.jar` or `-dev.jar`.
6. Back up your world, remove the older Night Splitters JAR, and test in a separate world first.

Important: This code has not been compiled or run in Minecraft here. Creative damage handling is experimental and may require further changes. The wave tracker relies on loaded tracked spiders; unloading chunks can affect when a wave is considered complete. No guarantee of server-side behavior or compatibility with other mods until tested.
