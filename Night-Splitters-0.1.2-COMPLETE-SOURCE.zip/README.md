# Night Splitters 0.1.2 test source

Upload extracted files to GitHub repository root (including hidden `.github` folder) to run GitHub Actions with Java 25. Do not upload ZIP as the only file.

Planned: 2–3 cave spiders per wave; next wave 5–30 seconds after tracked wave clears; 25% slower defaults; Creative targeting and half damage; server-side Fabric mod.

**Not compiled or verified in Minecraft.** Keep your working 0.1.1 TEST JAR until a successful build and in-game testing. Existing `config/night-splitters.json` will retain its previous speed settings; adjust the multipliers or temporarily rename the config file after backup to use new defaults.
